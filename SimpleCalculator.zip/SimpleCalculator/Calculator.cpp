/*
 * Calculator.cpp
 *
 *  Date: [Enter date]
 *  Author: [Your Name]
 */

#include <iostream>

using namespace std;

int main() // Corrected the return type from 'void' to 'int'
{
    char statement[100]; // This variable is unused in the code
    double op1, op2; // Changed to double to handle both integers and doubles
    char operation;
    char answer = 'Y'; // Corrected the syntax error

    while (answer == 'Y' || answer == 'y') // Corrected the condition to check for both 'Y' and 'y'
    {
        cout << "Enter expression (e.g., 2 + 2): " << endl;
        cin >> op1 >> operation >> op2; // Corrected the input order

        switch (operation) {
        case '+':
            cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;
            break;
        case '-':
            cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
            break;
        case '*':
            cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;
            break;
        case '/':
            if (op2 != 0) {
                cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
            }
            else {
                cout << "Error: Division by zero is not allowed." << endl;
            }
            break;
        default:
            cout << "Error: Invalid operator." << endl;
            break;
        }

        cout << "Do you wish to evaluate another expression? (Y/N): " << endl;
        cin >> answer;
    }

    cout << "Program Finished." << endl;
    return 0; // Added return statement for int main()
}